find \( -iname '*.cpp' -o -iname '*.h' \) -exec sed -i -e '$a\' {} \;
